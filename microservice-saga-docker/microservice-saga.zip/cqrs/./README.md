sudo apt install openjdk-17-jdk

ls /usr/lib/jvm/

export JAVA_HOME=/usr/lib/jvm/java-1.17.0-openjdk-amd64
 
 mvn clean install

mvn clean install -DskipTests
 
docker images | grep food.ordering.system


https://github.com/DevProblems/springboot-opentelemetry-jaeger/blob/master/docker-compose.yml


com.food.ordering.system/order.service        1.0-SNAPSHOT   976239f97bc0   43 years ago    325MB
com.food.ordering.system/restaurant.service   1.0-SNAPSHOT   f4f7a8712c68   43 years ago    312MB
com.food.ordering.system/payment.service      1.0-SNAPSHOT   8d9f29c8c4cd   43 years ago    321MB
com.food.ordering.system/customer.service     1.0-SNAPSHOT   93903c5d2c87   43 years ago    286MB


docker run --rm com.food.ordering.system/customer.service:1.0-SNAPSHOT ls -alR




find . -type f -name "*.jar"

/workspace/BOOT-INF/lib/opentelemetry-javaagent-1.24.0.jar


JAVA_TOOL_OPTIONS: -Djava.security.properties=/layers/paketo-buildpacks_bellsoft-liberica/java-security-properties/java-security.properties -XX:+ExitOnOutOfMemoryError -XX:ActiveProcessorCount=4 -XX:MaxDirectMemorySize=10M -Xmx128709K -XX:MaxMetaspaceSize=144126K -XX:ReservedCodeCacheSize=240M -Xss1M -XX:+UnlockDiagnosticVMOptions -XX:NativeMemoryTracking=summary -XX:+PrintNMTStatistics -Dorg.springframework.cloud.bindings.boot.enable=true -javaagent:/workspace/BOOT-INF/lib/opentelemetry-javaagent-1.24.0.jar