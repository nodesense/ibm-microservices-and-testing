package com.demo.microservicetwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicetwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
