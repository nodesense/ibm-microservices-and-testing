package com.demo.microserviceone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
