# Microserviceone

Run this project as a Spring Boot app

It will start up on port 8661. 
