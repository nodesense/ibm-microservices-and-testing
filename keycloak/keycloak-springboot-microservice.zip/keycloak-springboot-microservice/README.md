# keycloak-springboot-microservice

Please refer Medium article for more details: 
https://medium.com/@ddezoysa/securing-spring-boot-rest-apis-with-keycloak-1d760b2004e




Login to Auth Server to   Oauth Token for employee1 and repeat the same for employee2, employee3

```

curl -X POST 'http://localhost:8024/auth/realms/food-order-system/protocol/openid-connect/token' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=password' \
--data-urlencode 'client_id=order-service' \
--data-urlencode 'client_secret=pTTGm4G24S6MDAV5z2tVBSIyycqqoJaS' \
--data-urlencode 'username=employee1' \
--data-urlencode 'password=mypassword'

```

Copy the access token from teh response and use token to access the pages

```
curl -X GET 'http://localhost:8001/test/user' \
--header 'Authorization: Bearer ACCESS_TOEKN'
```


```
curl -X GET 'http://localhost:8001/test/all-user' \
--header 'Authorization: Bearer ACCESS_TOEKN'
```


This should fail , no access for employee1 (user role)


```
curl -X GET 'http://localhost:8001/test/admin' \
--header 'Authorization: Bearer ACCESS_TOEKN'
```