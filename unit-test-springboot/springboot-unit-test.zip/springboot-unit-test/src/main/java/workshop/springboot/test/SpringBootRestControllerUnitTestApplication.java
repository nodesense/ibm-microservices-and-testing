package workshop.springboot.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestControllerUnitTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestControllerUnitTestApplication.class, args);
	}

}
