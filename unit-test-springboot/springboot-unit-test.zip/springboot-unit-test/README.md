
## Run Spring Boot application
```

mvn clean

mvn clean install

mvn test -Dtest=TutorialControllerTests
```

